# MobileComputationProject
## WorldInChat
A simple application that serves to defeat Facebook Messenger! After the release, we are going to rule the world!